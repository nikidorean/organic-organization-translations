# Introducción: Organización Orgánica

Organización Orgánica, o O² abreviadamente, es un catalizador de autoorganización compuesto por tres libros. O² describe cómo fomentar la autogestión en equipo, departamento u organización. 

El trabajo aún está en progreso, sin embargo, ya tenemos una versión del Libro de Juegos disponible aquí. 

Hay traducciones disponibles en [otro proyecto de GitHub](https://github.com/targetteal/organic-organization-translations).

Nuestras influencias incluyen:
- [Reinventar las organizaciones](https://arpaeditores.com/products/reinventar-las-organizaciones)
- [Holocracia](https://www.holacracy.org/)
- [Sociocracia 3.0](https://sociocracy30.org/)
- [Desarrollo Ágil de Software](https://es.wikipedia.org/wiki/Desarrollo_%C3%A1gil_de_software)
- [El Método GTD](https://gettingthingsdone.com/)
- [Responsive Organizarions](https://www.responsive.org/)

## Licencia

*_Organizaciones Orgánicass está licensiada bajo una <a rel="license" href="http://creativecommons.org/licenses/by-sa/4.0/">Creative Commons Attribution-ShareAlike 4.0 International License</a>._*

<a rel="license" href="http://creativecommons.org/licenses/by-sa/4.0/" target="_blank"><img alt="Creative Commons License" style="border-width:0" src="https://i.creativecommons.org/l/by-sa/4.0/88x31.png" /></a> 
